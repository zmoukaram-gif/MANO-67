// script.js - simple interactivity
document.addEventListener('DOMContentLoaded', function(){
  // Mobile menu toggle
  const btn = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  btn?.addEventListener('click', function(){
    const expanded = this.getAttribute('aria-expanded') === 'true';
    this.setAttribute('aria-expanded', String(!expanded));
    if(nav) nav.style.display = expanded ? 'none' : 'block';
  });

  // Contact form (demo client-side only)
  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');

  form?.addEventListener('submit', function(e){
    e.preventDefault();
    // simple validation
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();

    if(name.length < 2){
      status.textContent = 'Le nom est trop court.';
      return;
    }
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
      status.textContent = 'Merci de fournir un email valide.';
      return;
    }
    if(message.length < 10){
      status.textContent = 'Le message est trop court.';
      return;
    }

    // simulate success (no backend)
    status.textContent = 'Merci — message reçu (démo).';
    form.reset();
  });
});
